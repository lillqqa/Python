

def test_make_one_point():
    pass
