class Point():
    pass
